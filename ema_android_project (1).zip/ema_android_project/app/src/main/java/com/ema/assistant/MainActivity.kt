package com.ema.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private val voiceRequest = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        layout.addView(TextView(this).apply {
            text = "емА — виртуальный помощник\n\nРазреши показ поверх других приложений, затем запусти персонажа."
            textSize = 20f
        })
        layout.addView(Button(this).apply {
            text = "1. Разрешить плавающее окно"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Разрешение уже выдано", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(Button(this).apply {
            text = "2. Запустить емА"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Сначала выдай разрешение на плавающее окно", Toast.LENGTH_LONG).show()
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    finish()
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "Команды и голос"
            setOnClickListener { showCommands() }
        })
        setContentView(layout)
        if (intent.getBooleanExtra("show_commands", false)) layout.post { showCommands() }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ru", "RU")
    }

    private fun showCommands() {
        val commands = arrayOf("Сказать команду голосом", "Открыть приложение", "Сменить обои", "Погода")
        AlertDialog.Builder(this)
            .setTitle("Команды емА")
            .setItems(commands) { _, which ->
                when (which) {
                    0 -> startVoiceRecognition()
                    1 -> chooseApp()
                    2 -> {
                        val intent = Intent(Intent.ACTION_SET_WALLPAPER)
                        startActivity(Intent.createChooser(intent, "Выбрать обои"))
                    }
                    3 -> {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wttr.in/?format=3"))
                        startActivity(intent)
                    }
                }
            }.setNegativeButton("Закрыть", null).show()
    }

    private fun startVoiceRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Скажи команду для емА")
        }
        try { startActivityForResult(intent, voiceRequest) }
        catch (_: Exception) { Toast.makeText(this, "На устройстве нет службы распознавания речи", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated in Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            handleCommand(spoken)
        }
    }

    private fun handleCommand(command: String) {
        val c = command.lowercase(Locale("ru", "RU"))
        when {
            "обои" in c -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Выбрать обои"))
            "погод" in c -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wttr.in/?format=3")))
            "открой" in c || "запусти" in c -> chooseApp()
            else -> {
                tts?.speak("Я услышал: $command. Для этой команды пока нет действия.", TextToSpeech.QUEUE_FLUSH, null, "ema_reply")
                Toast.makeText(this, "Распознано: $command", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun chooseApp() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0).sortedBy { it.loadLabel(pm).toString().lowercase() }
        val labels = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Открыть приложение").setItems(labels) { _, index ->
            val launch = pm.getLaunchIntentForPackage(apps[index].activityInfo.packageName)
            if (launch != null) startActivity(launch)
        }.setNegativeButton("Отмена", null).show()
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
