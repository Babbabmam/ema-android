package com.ema.assistant

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import android.speech.tts.TextToSpeech
import java.util.Locale

class OverlayService : Service(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private lateinit var wm: WindowManager
    private var avatar: ImageView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var greeting: android.widget.TextView? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Нужно разрешение на показ поверх приложений", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        if (avatar == null) {\n            tts = TextToSpeech(this, this)\n            showAvatar()\n        }
        return START_STICKY
    }

    private fun showAvatar() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val params = WindowManager.LayoutParams(
            190, 190, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 180 }

        avatar = ImageView(this).apply {
            setImageResource(R.drawable.ema_character)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "емА. Нажми, чтобы открыть команды"
            setOnTouchListener(object : android.view.View.OnTouchListener {
                var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
                var moved = false
                override fun onTouch(v: android.view.View, event: MotionEvent): Boolean {
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            downX = event.rawX; downY = event.rawY
                            startX = params.x; startY = params.y; moved = false
                            return true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (event.rawX - downX).toInt()
                            val dy = (event.rawY - downY).toInt()
                            if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 12) moved = true
                            params.x = startX + dx; params.y = startY + dy
                            wm.updateViewLayout(v, params)
                            return true
                        }
                        MotionEvent.ACTION_UP -> {
                            if (!moved) openCommands()
                            return true
                        }
                    }
                    return false
                }
            })
        }
        wm.addView(avatar, params)
        showGreeting()
    }

    private fun showGreeting() {
        val text = android.widget.TextView(this).apply {
            setBackgroundColor(0xEE202020.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 15f
            setPadding(24, 18, 24, 18)
            text = "Привет! Я емА, твой виртуальный помощник. Я был недавно создан, но попытаюсь тебе помочь. Твои указания?"
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 380 }
        greeting = text
        try { wm.addView(text, p) } catch (_: Exception) {}
        handler.postDelayed({
            try { greeting?.let { wm.removeView(it) } } catch (_: Exception) {}
            greeting = null
        }, 6000)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ru", "RU")
            tts?.speak(
                "Привет! Я емА, твой виртуальный помощник. Я был недавно создан, но попытаюсь тебе помочь. Твои указания?",
                TextToSpeech.QUEUE_FLUSH, null, "ema_greeting"
            )
        }
    }

    private fun openCommands() {
        val launch = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra("show_commands", true)
        startActivity(launch)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)\n        tts?.stop()\n        tts?.shutdown()
        try { greeting?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { avatar?.let { wm.removeView(it) } } catch (_: Exception) {}
        avatar = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
